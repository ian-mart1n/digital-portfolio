## Ian Martin

I am an eighteen year old Senior attending Kennett High School in North Conway. My field of interest is in Computer Science in which I am proficient having completed numerous projects within a group and independently. I have experience with coding languages 'C' and 'javaScript'. I also have a working understanding of HTML and CSS and am proficient in reactNative. I plan on seeking an internship at The Echo Group in Conway. 

### My Projects
Some of the many projects that I have created and/or worked on include 
1. Virtual Air Hockey
2. Kennett High School's Spirit Week Arcade
3. Taijitu Symbol


### Contact Me
1. Email: [lord.ian777@gmail.com]
2. Phone: 603-307-0761
3. Github:[ian-mart1n]
4. repl: @IanMartin2



